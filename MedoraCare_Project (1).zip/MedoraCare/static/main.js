document.addEventListener("DOMContentLoaded", () => {
    const menuBtn = document.getElementById("menuBtn");
    const mobileMenu = document.getElementById("mobileMenu");
    if (menuBtn && mobileMenu) {
        menuBtn.addEventListener("click", () => mobileMenu.classList.toggle("show"));
    }

    const dateInput = document.getElementById("appointmentDate");
    if (dateInput) {
        const today = new Date();
        const local = new Date(today.getTime() - today.getTimezoneOffset() * 60000);
        dateInput.min = local.toISOString().split("T")[0];
    }

    document.querySelectorAll(".flash").forEach(el => {
        setTimeout(() => {
            el.style.opacity = "0";
            setTimeout(() => el.remove(), 350);
        }, 5000);
    });

    const searchBtn = document.getElementById("navSearchBtn");
    if (searchBtn) {
        searchBtn.addEventListener("click", () => {
            window.location.href = "/hospitals";
        });
    }
});
