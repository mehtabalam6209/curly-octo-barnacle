import sqlite3
from pathlib import Path
from werkzeug.security import generate_password_hash

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "medoracare.db"


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    conn = get_db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'patient',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS hospitals (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        city TEXT NOT NULL,
        address TEXT NOT NULL,
        phone TEXT,
        rating REAL DEFAULT 4.5,
        specialties TEXT,
        lat REAL NOT NULL,
        lng REAL NOT NULL,
        image TEXT,
        description TEXT
    );

    CREATE TABLE IF NOT EXISTS doctors (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        specialty TEXT NOT NULL,
        qualification TEXT,
        experience INTEGER DEFAULT 5,
        hospital_id INTEGER NOT NULL,
        fee INTEGER DEFAULT 500,
        available_days TEXT DEFAULT 'Mon,Tue,Wed,Thu,Fri',
        available_time TEXT DEFAULT '10:00 AM - 2:00 PM',
        image TEXT,
        FOREIGN KEY (hospital_id) REFERENCES hospitals(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS appointments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        doctor_id INTEGER NOT NULL,
        hospital_id INTEGER NOT NULL,
        appointment_date TEXT NOT NULL,
        appointment_time TEXT NOT NULL,
        token INTEGER NOT NULL,
        status TEXT DEFAULT 'Booked',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE,
        FOREIGN KEY (hospital_id) REFERENCES hospitals(id) ON DELETE CASCADE,
        UNIQUE(doctor_id, appointment_date, appointment_time)
    );
    """)

    hospital_count = conn.execute("SELECT COUNT(*) FROM hospitals").fetchone()[0]
    if hospital_count == 0:
        hospitals = [
            ("CityCare Multispeciality Hospital", "Bhopal", "MP Nagar, Bhopal, Madhya Pradesh", "0755-4012000", 4.8,
             "Cardiology, Neurology, Orthopedics, General Medicine", 23.2335, 77.4295,
             "https://images.unsplash.com/photo-1586773860418-d37222d8fce3?auto=format&fit=crop&w=900&q=80",
             "A modern multispeciality hospital with emergency, diagnostics and specialist consultations."),
            ("Sunrise Multispeciality", "Bhopal", "Kolar Road, Bhopal, Madhya Pradesh", "0755-4201100", 4.6,
             "Pediatrics, Dermatology, Gynecology, General Medicine", 23.1765, 77.4346,
             "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&w=900&q=80",
             "Patient-focused care with multiple specialist departments and digital appointment support."),
            ("Aster Hospital", "Bhopal", "Arera Colony, Bhopal, Madhya Pradesh", "0755-4552200", 4.7,
             "Cardiology, ENT, Orthopedics, Surgery", 23.2124, 77.4348,
             "https://images.unsplash.com/photo-1516841273335-e39b37888115?auto=format&fit=crop&w=900&q=80",
             "Comprehensive clinical services with specialist doctors and diagnostic facilities."),
            ("Apollo City Hospital", "Indore", "Vijay Nagar, Indore, Madhya Pradesh", "0731-4905000", 4.7,
             "Cardiology, Neurology, Oncology, Orthopedics", 22.7533, 75.8937,
             "https://images.unsplash.com/photo-1538108149393-fbbd81895907?auto=format&fit=crop&w=900&q=80",
             "Specialist-led healthcare services in central Indore."),
            ("Metro Health Centre", "Delhi", "Saket, New Delhi", "011-44001000", 4.6,
             "Cardiology, Neurology, Pediatrics, Surgery", 28.5244, 77.2066,
             "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=900&q=80",
             "Multi-department urban healthcare centre."),
            ("Harbor Medical Institute", "Mumbai", "Andheri East, Mumbai, Maharashtra", "022-46002000", 4.7,
             "Cardiology, Dermatology, Orthopedics, General Medicine", 19.1176, 72.8636,
             "https://images.unsplash.com/photo-1587351021759-3e566b6af7cc?auto=format&fit=crop&w=900&q=80",
             "Specialist consultations and diagnostics in Mumbai."),
            ("PrimeCare Hospital", "Pune", "Baner, Pune, Maharashtra", "020-47003000", 4.6,
             "Pediatrics, Neurology, ENT, General Medicine", 18.5590, 73.7868,
             "https://images.unsplash.com/photo-1504439468489-c8920d796a29?auto=format&fit=crop&w=900&q=80",
             "Accessible specialist healthcare in Pune."),
            ("Nova Multispeciality", "Hyderabad", "Hitech City, Hyderabad, Telangana", "040-48004000", 4.8,
             "Cardiology, Oncology, Neurology, Orthopedics", 17.4435, 78.3772,
             "https://images.unsplash.com/photo-1551076805-e1869033e561?auto=format&fit=crop&w=900&q=80",
             "Modern multispeciality care with digital booking.")
        ]
        conn.executemany("""
            INSERT INTO hospitals
            (name, city, address, phone, rating, specialties, lat, lng, image, description)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, hospitals)

        doctors = [
            ("Dr. Rahul Sharma", "General Medicine", "MBBS, MD", 12, 1, 700, "Mon,Tue,Wed,Thu,Fri", "10:00 AM - 2:00 PM"),
            ("Dr. Priya Mehta", "Cardiologist", "MBBS, MD, DM", 10, 1, 1000, "Mon,Wed,Fri", "3:00 PM - 7:00 PM"),
            ("Dr. Arjun Verma", "Orthopedic", "MBBS, MS", 9, 1, 800, "Tue,Thu,Sat", "11:00 AM - 4:00 PM"),
            ("Dr. Neha Kapoor", "Pediatrician", "MBBS, DCH", 8, 2, 600, "Mon,Tue,Thu,Fri", "9:00 AM - 1:00 PM"),
            ("Dr. Riya Singh", "Dermatologist", "MBBS, MD", 7, 2, 750, "Wed,Thu,Sat", "2:00 PM - 6:00 PM"),
            ("Dr. Aman Khan", "Neurologist", "MBBS, DM", 14, 3, 1100, "Mon,Wed,Fri", "4:00 PM - 8:00 PM"),
            ("Dr. Kavya Rao", "Cardiologist", "MBBS, MD, DM", 11, 4, 1200, "Mon,Tue,Thu", "10:00 AM - 1:00 PM"),
            ("Dr. Sameer Joshi", "Neurologist", "MBBS, MD, DM", 13, 5, 1100, "Tue,Wed,Fri", "12:00 PM - 4:00 PM"),
            ("Dr. Isha Patel", "Dermatologist", "MBBS, MD", 6, 6, 800, "Mon,Thu,Sat", "10:00 AM - 3:00 PM"),
            ("Dr. Vikram Rao", "Orthopedic", "MBBS, MS", 10, 7, 850, "Mon,Wed,Fri", "9:00 AM - 2:00 PM"),
            ("Dr. Sara Ali", "Oncologist", "MBBS, MD, DM", 15, 8, 1300, "Tue,Thu,Sat", "11:00 AM - 4:00 PM")
        ]
        conn.executemany("""
            INSERT INTO doctors
            (name, specialty, qualification, experience, hospital_id, fee, available_days, available_time)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, doctors)

    admin_exists = conn.execute("SELECT id FROM users WHERE email = ?", ("admin@medoracare.com",)).fetchone()
    if not admin_exists:
        conn.execute(
            "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)",
            ("System Admin", "admin@medoracare.com", generate_password_hash("admin123"), "admin")
        )

    conn.commit()
    conn.close()
