# MedoraCare

Premium Flask + SQLite healthcare discovery and appointment college project.

## Run in VS Code / Windows PowerShell

1. Open this folder in VS Code.
2. Open Terminal.
3. Run:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py
```

4. Open http://127.0.0.1:5000

Demo admin:
email: admin@medoracare.com
password: admin123

The SQLite database is created automatically on first run.
No API key is required for the map because it uses Leaflet + OpenStreetMap tiles.
