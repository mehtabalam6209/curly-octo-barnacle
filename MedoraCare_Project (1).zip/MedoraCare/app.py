from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from database import get_db, init_db

app = Flask(__name__)
app.secret_key = "medoracare-dev-secret-change-this"
init_db()


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            flash("Please login to continue.", "warning")
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if session.get("role") != "admin":
            flash("Admin access required.", "danger")
            return redirect(url_for("home"))
        return view(*args, **kwargs)
    return wrapped


@app.context_processor
def inject_globals():
    return {
        "logged_in": "user_id" in session,
        "current_user": session.get("name"),
        "user_role": session.get("role")
    }


@app.route("/")
def home():
    conn = get_db()
    hospitals = conn.execute("SELECT * FROM hospitals ORDER BY rating DESC LIMIT 3").fetchall()
    doctors = conn.execute("""
        SELECT doctors.*, hospitals.name AS hospital_name, hospitals.city
        FROM doctors JOIN hospitals ON hospitals.id = doctors.hospital_id
        ORDER BY doctors.experience DESC LIMIT 4
    """).fetchall()
    conn.close()
    return render_template("home.html", hospitals=hospitals, doctors=doctors)


@app.route("/hospitals")
def hospitals():
    city = request.args.get("city", "").strip()
    q = request.args.get("q", "").strip()
    conn = get_db()
    sql = "SELECT * FROM hospitals WHERE 1=1"
    params = []
    if city:
        sql += " AND LOWER(city) = LOWER(?)"
        params.append(city)
    if q:
        sql += " AND (name LIKE ? OR city LIKE ? OR specialties LIKE ?)"
        term = f"%{q}%"
        params.extend([term, term, term])
    sql += " ORDER BY rating DESC, name"
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return render_template("hospitals.html", hospitals=rows, city=city, q=q)


@app.route("/hospital/<int:hospital_id>")
def hospital(hospital_id):
    conn = get_db()
    hospital_row = conn.execute("SELECT * FROM hospitals WHERE id = ?", (hospital_id,)).fetchone()
    doctors = conn.execute("""
        SELECT * FROM doctors WHERE hospital_id = ? ORDER BY experience DESC
    """, (hospital_id,)).fetchall()
    conn.close()
    if not hospital_row:
        flash("Hospital not found.", "danger")
        return redirect(url_for("hospitals"))
    return render_template("hospital.html", hospital=hospital_row, doctors=doctors)


@app.route("/doctors")
def doctors():
    specialty = request.args.get("specialty", "").strip()
    city = request.args.get("city", "").strip()
    q = request.args.get("q", "").strip()
    conn = get_db()
    sql = """
        SELECT doctors.*, hospitals.name AS hospital_name, hospitals.city
        FROM doctors JOIN hospitals ON hospitals.id = doctors.hospital_id
        WHERE 1=1
    """
    params = []
    if specialty:
        sql += " AND LOWER(doctors.specialty) LIKE LOWER(?)"
        params.append(f"%{specialty}%")
    if city:
        sql += " AND LOWER(hospitals.city) = LOWER(?)"
        params.append(city)
    if q:
        sql += " AND (doctors.name LIKE ? OR doctors.specialty LIKE ? OR hospitals.name LIKE ?)"
        term = f"%{q}%"
        params.extend([term, term, term])
    sql += " ORDER BY doctors.experience DESC"
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return render_template("doctors.html", doctors=rows, specialty=specialty, city=city, q=q)


@app.route("/appointments", methods=["GET", "POST"])
@login_required
def appointments():
    conn = get_db()
    doctors = conn.execute("""
        SELECT doctors.*, hospitals.name AS hospital_name, hospitals.city
        FROM doctors JOIN hospitals ON hospitals.id = doctors.hospital_id
        ORDER BY doctors.name
    """).fetchall()

    if request.method == "POST":
        doctor_id = request.form.get("doctor_id", type=int)
        appointment_date = request.form.get("appointment_date", "").strip()
        appointment_time = request.form.get("appointment_time", "").strip()

        if not doctor_id or not appointment_date or not appointment_time:
            flash("Please fill all appointment fields.", "warning")
            conn.close()
            return render_template("appointments.html", doctors=doctors)

        try:
            chosen = datetime.strptime(appointment_date, "%Y-%m-%d").date()
            if chosen < datetime.now().date():
                flash("Appointment date cannot be in the past.", "danger")
                conn.close()
                return render_template("appointments.html", doctors=doctors)
        except ValueError:
            flash("Invalid appointment date.", "danger")
            conn.close()
            return render_template("appointments.html", doctors=doctors)

        doctor = conn.execute("SELECT * FROM doctors WHERE id = ?", (doctor_id,)).fetchone()
        if not doctor:
            flash("Doctor not found.", "danger")
            conn.close()
            return render_template("appointments.html", doctors=doctors)

        taken = conn.execute("""
            SELECT id FROM appointments
            WHERE doctor_id = ? AND appointment_date = ? AND appointment_time = ?
            AND status = 'Booked'
        """, (doctor_id, appointment_date, appointment_time)).fetchone()

        if taken:
            flash("That time slot is already booked. Please choose another slot.", "danger")
            conn.close()
            return render_template("appointments.html", doctors=doctors)

        token = conn.execute("""
            SELECT COALESCE(MAX(token), 0) + 1 FROM appointments
            WHERE hospital_id = ? AND appointment_date = ? AND status = 'Booked'
        """, (doctor["hospital_id"], appointment_date)).fetchone()[0]

        try:
            conn.execute("""
                INSERT INTO appointments
                (user_id, doctor_id, hospital_id, appointment_date, appointment_time, token)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (session["user_id"], doctor_id, doctor["hospital_id"],
                  appointment_date, appointment_time, token))
            conn.commit()
            flash(f"Appointment confirmed. Your token is #{token}.", "success")
            conn.close()
            return redirect(url_for("my_appointments"))
        except Exception:
            conn.rollback()
            flash("Unable to book this slot. Please try again.", "danger")

    conn.close()
    return render_template("appointments.html", doctors=doctors)


@app.route("/my-appointments")
@login_required
def my_appointments():
    conn = get_db()
    rows = conn.execute("""
        SELECT appointments.*, doctors.name AS doctor_name, doctors.specialty,
               hospitals.name AS hospital_name, hospitals.city
        FROM appointments
        JOIN doctors ON doctors.id = appointments.doctor_id
        JOIN hospitals ON hospitals.id = appointments.hospital_id
        WHERE appointments.user_id = ?
        ORDER BY appointment_date DESC, appointment_time DESC
    """, (session["user_id"],)).fetchall()
    conn.close()
    return render_template("appointments_list.html", appointments=rows)


@app.post("/appointment/<int:appointment_id>/cancel")
@login_required
def cancel_appointment(appointment_id):
    conn = get_db()
    row = conn.execute("""
        SELECT id FROM appointments WHERE id = ? AND user_id = ? AND status = 'Booked'
    """, (appointment_id, session["user_id"])).fetchone()
    if row:
        conn.execute("UPDATE appointments SET status = 'Cancelled' WHERE id = ?", (appointment_id,))
        conn.commit()
        flash("Appointment cancelled successfully.", "success")
    else:
        flash("Appointment not found or already cancelled.", "warning")
    conn.close()
    return redirect(url_for("my_appointments"))


@app.route("/queue")
def queue():
    conn = get_db()
    stats = conn.execute("""
        SELECT hospitals.name, hospitals.city,
               COUNT(CASE WHEN appointments.status='Booked' THEN 1 END) AS active_tokens
        FROM hospitals LEFT JOIN appointments ON hospitals.id = appointments.hospital_id
        GROUP BY hospitals.id ORDER BY active_tokens DESC
    """).fetchall()
    conn.close()
    return render_template("queue.html", stats=stats)


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        conn = get_db()
        user = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
        conn.close()
        if user and check_password_hash(user["password"], password):
            session["user_id"] = user["id"]
            session["name"] = user["name"]
            session["role"] = user["role"]
            flash(f"Welcome back, {user['name'].split()[0]}!", "success")
            next_page = request.args.get("next")
            return redirect(next_page if next_page and next_page.startswith("/") else url_for("dashboard"))
        flash("Invalid email or password.", "danger")
    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")

        if len(name) < 2 or "@" not in email:
            flash("Please enter a valid name and email.", "warning")
        elif len(password) < 6:
            flash("Password must contain at least 6 characters.", "warning")
        elif password != confirm:
            flash("Passwords do not match.", "danger")
        else:
            conn = get_db()
            try:
                conn.execute(
                    "INSERT INTO users (name, email, password) VALUES (?, ?, ?)",
                    (name, email, generate_password_hash(password))
                )
                conn.commit()
                flash("Account created successfully. Please login.", "success")
                conn.close()
                return redirect(url_for("login"))
            except Exception:
                conn.rollback()
                conn.close()
                flash("This email is already registered.", "danger")
    return render_template("register.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("home"))


@app.route("/dashboard")
@login_required
def dashboard():
    conn = get_db()
    upcoming = conn.execute("""
        SELECT appointments.*, doctors.name AS doctor_name, doctors.specialty,
               hospitals.name AS hospital_name, hospitals.city
        FROM appointments
        JOIN doctors ON doctors.id = appointments.doctor_id
        JOIN hospitals ON hospitals.id = appointments.hospital_id
        WHERE appointments.user_id = ? AND appointments.status = 'Booked'
        ORDER BY appointment_date, appointment_time
        LIMIT 5
    """, (session["user_id"],)).fetchall()
    total = conn.execute(
        "SELECT COUNT(*) FROM appointments WHERE user_id = ?", (session["user_id"],)
    ).fetchone()[0]
    conn.close()
    return render_template("dashboard.html", appointments=upcoming, total=total)


@app.route("/admin")
@admin_required
def admin():
    conn = get_db()
    users = conn.execute("SELECT id, name, email, role, created_at FROM users ORDER BY id DESC").fetchall()
    appointments = conn.execute("""
        SELECT appointments.*, users.name AS patient_name, doctors.name AS doctor_name,
               hospitals.name AS hospital_name
        FROM appointments
        JOIN users ON users.id = appointments.user_id
        JOIN doctors ON doctors.id = appointments.doctor_id
        JOIN hospitals ON hospitals.id = appointments.hospital_id
        ORDER BY appointments.created_at DESC
        LIMIT 20
    """).fetchall()
    hospital_count = conn.execute("SELECT COUNT(*) FROM hospitals").fetchone()[0]
    doctor_count = conn.execute("SELECT COUNT(*) FROM doctors").fetchone()[0]
    appointment_count = conn.execute("SELECT COUNT(*) FROM appointments").fetchone()[0]
    conn.close()
    return render_template(
        "admin.html", users=users, appointments=appointments,
        hospital_count=hospital_count, doctor_count=doctor_count,
        appointment_count=appointment_count
    )


@app.route("/api/hospitals")
def api_hospitals():
    city = request.args.get("city", "").strip()
    conn = get_db()
    if city:
        rows = conn.execute(
            "SELECT id, name, city, address, lat, lng, rating FROM hospitals WHERE LOWER(city)=LOWER(?)",
            (city,)
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT id, name, city, address, lat, lng, rating FROM hospitals"
        ).fetchall()
    conn.close()
    return jsonify([dict(row) for row in rows])


@app.errorhandler(404)
def not_found(error):
    return render_template("base.html", error_message="The page you requested was not found."), 404


if __name__ == "__main__":
    app.run(debug=True)
